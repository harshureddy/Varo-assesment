require = require('esm')(module /*, options*/);
module.exports = require('./server/index.js');
